# Getting Started with Create React App

This project is a ticketbooking app. Here user can See available tickets and can book them. Users can also check their booked tickets

## How to start this project
 
    step 1: git clone https://github.com/vikaskrsharma/TicketBookingFrontend.git
    step 2: npm i
    step 3:  npm  start
