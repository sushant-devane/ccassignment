import React from 'react'
import "./Common.css";
export default function Loader() {
  return (
    <div><div class="loader"></div></div>
  )
}
