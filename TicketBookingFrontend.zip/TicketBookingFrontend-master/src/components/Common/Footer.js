import React from 'react'
import './Common.css';
export default function Footer() {
  return (
    <div className='footer'>
        Footer
    </div>
  )
}
